(function(){function e(e){return e}(function(){let e=!1;function t(){return globalThis.browser&&globalThis.browser.runtime?globalThis.browser:globalThis.chrome}function n(){let e=t();return!!(e&&e.sidePanel&&typeof e.sidePanel.open==`function`)}function r(){let e=t();return!!(e&&e.sidebarAction&&typeof e.sidebarAction.open==`function`)}function i(){return n()||r()}async function a(){let i=t();if(n()&&typeof i.sidePanel.setPanelBehavior==`function`)try{await i.sidePanel.setPanelBehavior({openPanelOnActionClick:!0})}catch{}!e&&r()&&i.action&&i.action.onClicked&&(i.action.onClicked.addListener(async()=>{try{await i.sidebarAction.open()}catch{}}),e=!0)}async function o(e,r){let i=t();n()&&typeof i.sidePanel.setOptions==`function`&&e&&await i.sidePanel.setOptions(r?{tabId:e,path:`sidepanel.html`,enabled:!0}:{tabId:e,enabled:!1})}function s(e){let i=t(),a=e||{};if(n()){let e=i.sidePanel.open(a),t=a.tabId?o(a.tabId,!0):Promise.resolve();return Promise.all([e,t]).then(([e])=>e)}if(r())return i.sidebarAction.open();throw Error(`Sidebar API is unavailable.`)}globalThis.SummarizerBrowserApi={getApi:t,hasChromeSidePanel:n,hasFirefoxSidebar:r,hasSupportedSidebar:i,configurePrimarySidebarBehavior:a,openPrimarySidebar:s,setSidePanelEnabledForTab:o}})(),(function(){globalThis.SummarizerMessages={types:{SUMMARIZE_ACTIVE_TAB:`SUMMARIZE_ACTIVE_TAB`,EXTRACT_CONTENT:`EXTRACT_CONTENT`,FETCH_COURSE_CONTENT:`FETCH_COURSE_CONTENT`,SUMMARY_UPDATED:`SUMMARY_UPDATED`,SUMMARY_CHUNK:`SUMMARY_CHUNK`,SUMMARY_ERROR:`SUMMARY_ERROR`,CANCEL_SUMMARIZE:`CANCEL_SUMMARIZE`,OPEN_SIDE_PANEL:`OPEN_SIDE_PANEL`,GET_PUBLIC_SETTINGS:`GET_PUBLIC_SETTINGS`,DEEP_DIVE_ACTIVE_TAB:`DEEP_DIVE_ACTIVE_TAB`,SETTINGS_UPDATED:`SETTINGS_UPDATED`}}})(),(function(){let e=/(\*\*(.+?)\*\*|__(.+?)__|`([^`]+)`|\*(.+?)\*|_([^_]+)_)/g;function t(t,n){let r=String(n||``),i=0,a;for(e.lastIndex=0;a=e.exec(r);){a.index>i&&t.appendChild(document.createTextNode(r.slice(i,a.index)));let n=a[2]||a[3]?`strong`:a[4]?`code`:`em`,o=a[2]||a[3]||a[4]||a[5]||a[6]||``,s=document.createElement(n);s.textContent=o,t.appendChild(s),i=e.lastIndex}i<r.length&&t.appendChild(document.createTextNode(r.slice(i)))}function n(e){let n=String(e||``).replace(/\r/g,``),r=document.createDocumentFragment();if(!n.trim())return r;let i=n.split(`
`),a=null;function o(){a&&=(r.appendChild(a),null)}return i.forEach(e=>{let n=e.trimEnd().trim();if(!n){o();return}let i=n.match(/^(#{1,6})\s+(.+)$/);if(i){o();let e=document.createElement(`h${Math.min(i[1].length+1,6)}`);t(e,i[2]),r.appendChild(e);return}let s=n.match(/^[-*•]\s+(.+)$/);if(s){a||=document.createElement(`ul`);let e=document.createElement(`li`);t(e,s[1]),a.appendChild(e);return}o();let c=document.createElement(`p`);t(c,n),r.appendChild(c)}),o(),r}globalThis.SummarizerMarkdown={renderMarkdown:n}})(),(function(){let e=new Set([`system`,`light`,`dark`]),t=new Set([`sm`,`md`,`lg`,`xl`]);function n(t){let n=String(t||`system`).toLowerCase();return e.has(n)?n:`system`}function r(e){let n=String(e||`md`).toLowerCase();return t.has(n)?n:`md`}function i(e){let t=n(e);return t===`system`?typeof window<`u`&&window.matchMedia&&window.matchMedia(`(prefers-color-scheme: dark)`).matches?`dark`:`light`:t}function a(e,t){let n=t||document.documentElement,r=i(e);return n.dataset.theme=r,n.style.colorScheme=r,r}function o(e,t){let n=t||document.documentElement,i=r(e);return n.dataset.fontScale=i,i}function s(e){if(typeof window>`u`||!window.matchMedia)return function(){};let t=window.matchMedia(`(prefers-color-scheme: dark)`),n=()=>e(t.matches?`dark`:`light`);return typeof t.addEventListener==`function`?(t.addEventListener(`change`,n),function(){t.removeEventListener(`change`,n)}):(t.addListener(n),function(){t.removeListener(n)})}globalThis.SummarizerTheme={THEME_VALUES:e,FONT_SCALE_VALUES:t,normalizeTheme:n,normalizeFontScale:r,resolveTheme:i,applyThemeToDocument:a,applyFontScaleToDocument:o,watchSystemTheme:s,sharedTokens:`
:host, :root {
  --font-display: "Plus Jakarta Sans", "Inter", -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif;
  --font-body: "Inter", -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif;
  --font-mono: "JetBrains Mono", "Fira Code", ui-monospace, SFMono-Regular, Menlo, Monaco, monospace;
  --font-reading: "Newsreader", "Lora", "Georgia", "Charter", "Iowan Old Style", serif;
  --space-1: 4px; --space-2: 8px; --space-3: 12px; --space-4: 16px;
  --space-5: 20px; --space-6: 24px; --space-8: 32px;
  --radius-xs: 5px; --radius-sm: 7px; --radius-md: 10px; --radius-lg: 14px; --radius-full: 9999px;
  
  --color-paper: #FAF8F5;
  --color-paper-2: #F2EFE9;
  --color-paper-elevated: #FFFFFF;
  --color-ink: #1C1917;
  --color-ink-2: #44403C;
  --color-ink-tertiary: #78716C;
  --color-rule: #E7E2DA;
  --color-rule-strong: #D6CEBE;
  
  --color-accent: #9A3412;
  --color-accent-hover: #7C2D12;
  --color-accent-light: #F5EBE1;
  --color-accent-subtle: #FAF4EE;
  --color-focus: #9A3412;
  --color-focus-ring: 0 0 0 3px rgba(154, 52, 18, 0.22);
  
  --color-success: #16A34A;
  --color-error: #DC2626;
  --color-warning: #D97706;

  --bg: var(--color-paper);
  --surface: var(--color-paper-elevated);
  --surface-hover: var(--color-accent-subtle);
  --surface-muted: var(--color-paper-2);
  --text: var(--color-ink);
  --text-secondary: var(--color-ink-2);
  --text-tertiary: var(--color-ink-tertiary);
  --border: var(--color-rule);
  --accent-primary: var(--color-accent);
  --accent-secondary: var(--color-accent-hover);
  --shadow-xs: 0 1px 2px rgba(28, 25, 23, 0.05);
  --shadow-sm: 0 1px 3px rgba(28, 25, 23, 0.07);
  --shadow-md: 0 4px 12px -2px rgba(28, 25, 23, 0.09);
}
:host([data-theme="dark"]), :root[data-theme="dark"] {
  --color-paper: #141210;
  --color-paper-2: #1C1917;
  --color-paper-elevated: #262320;
  --color-ink: #F5F3EF;
  --color-ink-2: #D6D3D1;
  --color-ink-tertiary: #A8A29E;
  --color-rule: #34302C;
  --color-rule-strong: #4E4842;
  
  --color-accent: #E07A5F;
  --color-accent-hover: #F4987E;
  --color-accent-light: #3A231C;
  --color-accent-subtle: #221612;
  --color-focus: #E07A5F;
  --color-focus-ring: 0 0 0 3px rgba(224, 122, 95, 0.35);
  
  --color-success: #22C55E;
  --color-error: #EF4444;
  --color-warning: #F59E0B;

  --bg: var(--color-paper);
  --surface: var(--color-paper-elevated);
  --surface-hover: var(--color-accent-subtle);
  --surface-muted: var(--color-paper-2);
  --text: var(--color-ink);
  --text-secondary: var(--color-ink-2);
  --text-tertiary: var(--color-ink-tertiary);
  --border: var(--color-rule);
  --accent-primary: var(--color-accent);
  --accent-secondary: var(--color-accent-hover);
  --shadow-xs: 0 1px 2px rgba(0, 0, 0, 0.5);
  --shadow-sm: 0 2px 6px rgba(0, 0, 0, 0.5);
  --shadow-md: 0 6px 18px -2px rgba(0, 0, 0, 0.65);
}
`}})();function t(){let e=SummarizerMessages.types,t={host:null,shadow:null,button:null,panel:null,enabled:!0,latestResult:null,latestError:``,theme:`system`,stopThemeWatch:null};function n(e){if(globalThis.SummarizerTheme&&typeof SummarizerTheme.resolveTheme==`function`)return SummarizerTheme.resolveTheme(e||`system`);let t=String(e||`system`).toLowerCase();return t===`light`||t===`dark`?t:window.matchMedia&&window.matchMedia(`(prefers-color-scheme: dark)`).matches?`dark`:`light`}function r(e){t.theme=e||`system`,t.host&&(t.host.dataset.theme=n(t.theme))}function i(e){if(t.panel&&t.button&&(t.panel.classList.toggle(`visible`,e),t.button.classList.toggle(`open`,e),t.button.setAttribute(`aria-expanded`,String(e)),e)){let e=t.panel.querySelector(`button, [href], input, select, textarea, [tabindex]:not([tabindex="-1"])`);e&&e.focus()}}function a(e,t,n){let r=document.createElement(e);return t&&(r.className=t),n!==void 0&&(r.textContent=n),r}function o(){if(!t.panel)return;t.panel.replaceChildren();let e=a(`div`,`head`),n=a(`strong`,``,t.latestError?`Summary Error`:t.latestResult?t.latestResult.title||`Summary`:`Floating Summary`),r=a(`button`,`close-btn`,`Close`);if(r.type=`button`,r.dataset.close=``,e.append(n,r),t.panel.appendChild(e),t.latestError){t.panel.appendChild(a(`p`,`error`,t.latestError));let e=a(`div`,`actions`),n=a(`button`,`btn-primary`,`Retry`);n.type=`button`,n.dataset.retry=``,e.appendChild(n),t.panel.appendChild(e),s();return}if(!t.latestResult){t.panel.appendChild(a(`p`,``,`No summary yet. Use the floating button or the side panel.`));let e=a(`div`,`actions`),n=a(`button`,`btn-primary`,`Generate`);n.type=`button`,n.dataset.retry=``,e.appendChild(n),t.panel.appendChild(e),s();return}let i=String(t.latestResult.promptMode||``).toLowerCase()===`concepts`,o=a(`p`,`meta`,String(t.latestResult.sourceType||``)+(t.latestResult.promptMode?` · `+t.latestResult.promptMode:``));if(t.panel.appendChild(o),i)t.panel.appendChild(a(`p`,`summary`,`Open the side panel to view the Concepts mode result.`));else{let e=a(`section`);e.appendChild(a(`h4`,``,`Main Summary`));let n=a(`div`,`summary`);n.appendChild(SummarizerMarkdown.renderMarkdown(t.latestResult.summary||``)),e.appendChild(n),t.panel.appendChild(e);let r=a(`section`);r.appendChild(a(`h4`,``,`Executive Takeaways`));let i=a(`ul`),o=(t.latestResult.keyTakeaways||[]).slice(0,5);o.length||o.push(`No takeaways returned.`),o.forEach(e=>i.appendChild(a(`li`,``,e))),r.appendChild(i),t.panel.appendChild(r)}let c=a(`div`,`actions`);[[`Copy`,`copy`,``],[`Retry`,`retry`,``],[`Open Side Panel`,`sidepanel`,`btn-primary`]].forEach(([e,t,n])=>{let r=a(`button`,n,e);r.type=`button`,r.dataset[t]=``,c.appendChild(r)}),t.panel.appendChild(c),s()}function s(){if(!t.panel)return;let n=t.panel.querySelector(`[data-close]`);n&&(n.onclick=()=>i(!1));let r=t.panel.querySelector(`[data-retry]`);r&&(r.onclick=()=>c());let a=t.panel.querySelector(`[data-copy]`);a&&(a.onclick=async()=>{let e=t.latestResult;if(!e)return;let n=[e.title||`Summary`,``,e.summary||``,``,`Executive Takeaways`,...(e.keyTakeaways||[]).map(e=>`- `+e)].join(`
`);await navigator.clipboard.writeText(n)});let s=t.panel.querySelector(`[data-sidepanel]`);s&&(s.onclick=async()=>{let n=await chrome.runtime.sendMessage({type:e.OPEN_SIDE_PANEL});(!n||!n.ok)&&(t.latestError=n&&n.error||`Use the extension toolbar button. Chrome restricts opening the side panel from this in-page control.`,o(),i(!0))})}async function c(){if(t.latestError=``,o(),i(!0),t.button){t.button.disabled=!0,t.button.classList.add(`loading`);let e=t.button.querySelector(`.fab-label`);e&&(e.textContent=`Summarizing...`)}try{let n=await chrome.runtime.sendMessage({type:e.SUMMARIZE_ACTIVE_TAB});if(!n||!n.ok)throw Error(n&&n.error||`Summary failed.`);t.latestResult=n.result||null,t.latestError=``,o(),i(!0)}catch(e){t.latestError=e.message||`Summary failed.`,o(),i(!0)}finally{if(t.button){t.button.disabled=!1,t.button.classList.remove(`loading`);let e=t.button.querySelector(`.fab-label`);e&&(e.textContent=`Summarize`)}}}function l(){if(t.host||!t.enabled)return;t.host=document.createElement(`div`),t.host.style.position=`fixed`,t.host.style.right=`20px`,t.host.style.bottom=`20px`,t.host.style.zIndex=`2147483647`,t.host.dataset.theme=n(t.theme),t.shadow=t.host.attachShadow({mode:`open`});let e=globalThis.SummarizerTheme&&SummarizerTheme.sharedTokens||``,r=document.createElement(`style`);r.textContent=e+`
        :host { all: initial; font-family: var(--font-sans); }
        .fab {
          background: var(--accent-primary, #9A3412);
          color: #fff;
          border: 1px solid transparent;
          border-radius: 999px;
          padding: 9px 15px;
          cursor: pointer;
          box-shadow: 0 4px 14px rgba(154, 52, 18, 0.32);
          font: 600 12.5px/1.2 var(--font-display, var(--font-sans));
          display: inline-flex;
          align-items: center;
          gap: 7px;
          transition: background var(--duration-fast, 140ms) ease, transform var(--duration-fast, 140ms) ease, box-shadow var(--duration-fast, 140ms) ease;
        }
        .fab:hover:not(:disabled) {
          background: var(--accent-secondary, #7C2D12);
          transform: translateY(-1px) scale(1.02);
          box-shadow: 0 6px 18px rgba(154, 52, 18, 0.42);
        }
        .fab:active:not(:disabled) {
          transform: scale(0.98);
        }
        .fab:focus-visible {
          outline: 3px solid var(--color-focus, #9A3412);
          outline-offset: 2px;
        }
        .fab.loading {
          opacity: 0.85;
          pointer-events: none;
        }
        .fab.open .fab-icon {
          transform: rotate(45deg);
        }
        .fab-icon {
          display: inline-flex;
          transition: transform var(--duration-base, 220ms) ease;
        }
        .panel {
          display: none;
          width: min(360px, calc(100vw - 24px));
          max-height: calc(100vh - 80px);
          overflow: auto;
          margin-top: 10px;
          background: var(--surface, #FFFFFF);
          color: var(--text, #1C1917);
          border: 1px solid var(--border, #E7E2DA);
          border-radius: var(--radius-md, 10px);
          padding: 16px;
          box-shadow: 0 16px 36px rgba(0, 0, 0, 0.16);
          font: 13.5px/1.55 var(--font-body, var(--font-sans));
          animation: panel-in 220ms cubic-bezier(0.16, 1, 0.3, 1);
        }
        .panel.visible { display: block; }
        @keyframes panel-in {
          from { opacity: 0; transform: translateY(8px) scale(0.98); }
          to { opacity: 1; transform: translateY(0) scale(1); }
        }
        .head {
          display: flex;
          justify-content: space-between;
          gap: 8px;
          align-items: center;
          margin-bottom: 8px;
        }
        .close-btn, .actions button {
          border: 1px solid var(--border, #E7E2DA);
          background: var(--surface-muted, #F2EFE9);
          color: var(--text, #1C1917);
          border-radius: 999px;
          padding: 6px 10px;
          cursor: pointer;
          font: inherit;
          font-size: 12px;
          transition: all 140ms ease;
        }
        .close-btn:hover, .actions button:hover:not(:disabled) {
          border-color: var(--accent-primary, #9A3412);
          background: var(--surface-hover, #FAF4EE);
        }
        .actions {
          display: flex;
          flex-wrap: wrap;
          gap: 6px;
          margin-top: 12px;
        }
        .actions .btn-primary {
          background: var(--accent-primary, #9A3412);
          border-color: transparent;
          color: #fff;
          font-weight: 600;
          font-family: var(--font-display, var(--font-sans));
        }
        h4 {
          font-size: 11px;
          font-weight: 700;
          margin: 16px 0 8px;
          text-transform: uppercase;
          letter-spacing: 0.08em;
          color: var(--text-tertiary, #78716C);
        }
        .summary { white-space: pre-wrap; word-break: break-word; }
        ul { padding-left: 18px; margin: 0; }
        .meta { color: var(--text-tertiary, #78716C); margin: 0 0 12px; font-size: 12px; }
        .error { color: var(--error, #DC2626); background: #FEE2E2; padding: 12px; border-radius: 8px; font-size: 13px; margin: 12px 0; border: 1px solid rgba(220, 38, 38, 0.2); }
        *:focus-visible {
          outline: 3px solid var(--color-focus, #9A3412);
          outline-offset: 2px;
        }
        @media (prefers-reduced-motion: reduce) {
          *, *::before, *::after {
            animation-duration: 0.01ms !important;
            animation-iteration-count: 1 !important;
            transition-duration: 0.01ms !important;
          }
        }
        `,t.shadow.appendChild(r),t.button=a(`button`,`fab`),t.button.type=`button`,t.button.setAttribute(`aria-expanded`,`false`),t.button.setAttribute(`aria-controls`,`float-panel`),t.button.setAttribute(`aria-label`,`Open DeepDigest`);let s=a(`span`,`fab-icon`);s.setAttribute(`aria-hidden`,`true`);let l=document.createElementNS(`http://www.w3.org/2000/svg`,`svg`);[[`width`,`15`],[`height`,`15`],[`viewBox`,`0 0 24 24`],[`fill`,`none`],[`stroke`,`currentColor`],[`stroke-width`,`2.2`],[`stroke-linecap`,`round`],[`stroke-linejoin`,`round`]].forEach(([e,t])=>l.setAttribute(e,t));let u=document.createElementNS(`http://www.w3.org/2000/svg`,`path`);u.setAttribute(`d`,`M12 2v4M12 18v4M4.93 4.93l2.83 2.83M16.24 16.24l2.83 2.83M2 12h4M18 12h4M4.93 19.07l2.83-2.83M16.24 7.76l2.83-2.83`);let d=document.createElementNS(`http://www.w3.org/2000/svg`,`circle`);d.setAttribute(`cx`,`12`),d.setAttribute(`cy`,`12`),d.setAttribute(`r`,`4`),l.append(u,d),s.appendChild(l),t.button.append(s,a(`span`,`fab-label`,`Summarize`)),t.panel=a(`div`,`panel`),t.panel.id=`float-panel`,t.panel.setAttribute(`role`,`dialog`),t.panel.setAttribute(`aria-modal`,`true`),t.panel.setAttribute(`aria-label`,`DeepDigest floating panel`),t.shadow.append(t.button,t.panel),t.button.addEventListener(`click`,()=>{if(t.latestResult||t.latestError){let e=!t.panel.classList.contains(`visible`);e&&o(),i(e)}else c()}),t.shadow.addEventListener(`keydown`,e=>{e.key===`Escape`&&t.panel.classList.contains(`visible`)&&(i(!1),t.button.focus())}),document.documentElement.appendChild(t.host)}function u(){t.stopThemeWatch&&=(t.stopThemeWatch(),null),t.host&&t.host.remove(),t.host=null,t.shadow=null,t.button=null,t.panel=null}function d(e){t.enabled=!!(e&&e.showFloatingUi),t.theme=e&&e.theme||`system`,t.enabled?(l(),r(t.theme),!t.stopThemeWatch&&globalThis.SummarizerTheme&&SummarizerTheme.watchSystemTheme&&(t.stopThemeWatch=SummarizerTheme.watchSystemTheme(()=>{(t.theme||`system`)===`system`&&r(`system`)}))):u()}async function f(){try{let t=await chrome.runtime.sendMessage({type:e.GET_PUBLIC_SETTINGS});if(!t||!t.ok)throw Error(`Public settings are unavailable.`);d(t.settings)}catch(e){console.warn(`[Summarizer] Failed to sync floating UI:`,e)}}chrome.runtime.onMessage.addListener((n,r,a)=>{if(n.type===e.FETCH_COURSE_CONTENT){if(!globalThis.SummarizerSelectedTextExtractor||!globalThis.SummarizerCourseExtractor)return a({ok:!1,code:`EXTRACTORS_NOT_READY`,error:`Extractors are not loaded yet.`}),!0;let e=SummarizerSelectedTextExtractor.extractSelectedText();return e?(a({ok:!0,data:e}),!0):(SummarizerCourseExtractor.fetchCourseContent().then(e=>a({ok:!0,data:e})).catch(e=>a({ok:!1,error:e.message||`Course extraction failed.`})),!0)}if(n.type===e.EXTRACT_CONTENT){let e=globalThis.SummarizerExtractors;return!e||typeof e.extractBestContent!=`function`?(a({ok:!1,code:`EXTRACTORS_NOT_READY`,error:`The page extraction module is not ready. Refresh the page and try again.`}),!0):(e.extractBestContent().then(e=>a({ok:!0,data:e})).catch(e=>a({ok:!1,error:e.message||`Extraction failed.`})),!0)}if(n.type===e.SUMMARY_UPDATED){t.latestError=``,t.latestResult=n.result||null,o(),i(!0);return}if(n.type===e.SUMMARY_ERROR){t.latestError=n.error||`Summary failed.`,o(),i(!0);return}n.type===e.SETTINGS_UPDATED&&d(n.settings||{})}),chrome.storage.onChanged.addListener((e,t)=>{t===`local`&&e.summarizerSettings&&f().catch(()=>{})}),f().catch(()=>{})}var n=e({matches:[`<all_urls>`],runAt:`document_idle`,main(){t()}}),r={debug:(...e)=>([...e],void 0),log:(...e)=>([...e],void 0),warn:(...e)=>([...e],void 0),error:(...e)=>([...e],void 0)},i=globalThis.browser?.runtime?.id?globalThis.browser:globalThis.chrome,a=class e extends Event{static EVENT_NAME=o(`wxt:locationchange`);constructor(t,n){super(e.EVENT_NAME,{}),this.newUrl=t,this.oldUrl=n}};function o(e){return`${i?.runtime?.id}:content:${e}`}var s=typeof globalThis.navigation?.addEventListener==`function`;function c(e){let t,n=!1;return{run(){n||(n=!0,t=new URL(location.href),s?globalThis.navigation.addEventListener(`navigate`,e=>{let n=new URL(e.destination.url);n.href!==t.href&&(window.dispatchEvent(new a(n,t)),t=n)},{signal:e.signal}):e.setInterval(()=>{let e=new URL(location.href);e.href!==t.href&&(window.dispatchEvent(new a(e,t)),t=e)},1e3))}}}var l=class e{static SCRIPT_STARTED_MESSAGE_TYPE=o(`wxt:content-script-started`);id;abortController;locationWatcher=c(this);constructor(e,t){this.contentScriptName=e,this.options=t,this.id=Math.random().toString(36).slice(2),this.abortController=new AbortController,this.stopOldScripts(),this.listenForNewerScripts()}get signal(){return this.abortController.signal}abort(e){return this.abortController.abort(e)}get isInvalid(){return i.runtime?.id??this.notifyInvalidated(),this.signal.aborted}get isValid(){return!this.isInvalid}onInvalidated(e){return this.signal.addEventListener(`abort`,e),()=>this.signal.removeEventListener(`abort`,e)}block(){return new Promise(()=>{})}setInterval(e,t){let n=setInterval(()=>{this.isValid&&e()},t);return this.onInvalidated(()=>clearInterval(n)),n}setTimeout(e,t){let n=setTimeout(()=>{this.isValid&&e()},t);return this.onInvalidated(()=>clearTimeout(n)),n}requestAnimationFrame(e){let t=requestAnimationFrame((...t)=>{this.isValid&&e(...t)});return this.onInvalidated(()=>cancelAnimationFrame(t)),t}requestIdleCallback(e,t){let n=requestIdleCallback((...t)=>{this.signal.aborted||e(...t)},t);return this.onInvalidated(()=>cancelIdleCallback(n)),n}addEventListener(e,t,n,r){t===`wxt:locationchange`&&this.isValid&&this.locationWatcher.run(),e.addEventListener?.(t.startsWith(`wxt:`)?o(t):t,n,{...r,signal:this.signal})}notifyInvalidated(){this.abort(`Content script context invalidated`),r.debug(`Content script "${this.contentScriptName}" context invalidated`)}stopOldScripts(){document.dispatchEvent(new CustomEvent(e.SCRIPT_STARTED_MESSAGE_TYPE,{detail:{contentScriptName:this.contentScriptName,messageId:this.id}})),this.options?.noScriptStartedPostMessage||window.postMessage({type:e.SCRIPT_STARTED_MESSAGE_TYPE,contentScriptName:this.contentScriptName,messageId:this.id},`*`)}verifyScriptStartedEvent(e){let t=e.detail?.contentScriptName===this.contentScriptName,n=e.detail?.messageId===this.id;return t&&!n}listenForNewerScripts(){let t=e=>{e instanceof CustomEvent&&this.verifyScriptStartedEvent(e)&&this.notifyInvalidated()};document.addEventListener(e.SCRIPT_STARTED_MESSAGE_TYPE,t),this.onInvalidated(()=>document.removeEventListener(e.SCRIPT_STARTED_MESSAGE_TYPE,t))}},u={debug:(...e)=>([...e],void 0),log:(...e)=>([...e],void 0),warn:(...e)=>([...e],void 0),error:(...e)=>([...e],void 0)};return(async()=>{try{let{main:e,...t}=n;return await e(new l(`content`,t))}catch(e){throw u.error(`The content script "content" crashed on startup!`,e),e}})()})();