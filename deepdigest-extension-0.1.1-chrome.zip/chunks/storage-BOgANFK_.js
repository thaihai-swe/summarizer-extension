(function(){let e=document.createElement(`link`).relList;if(e&&e.supports&&e.supports(`modulepreload`))return;for(let e of document.querySelectorAll(`link[rel="modulepreload"]`))n(e);new MutationObserver(e=>{for(let t of e)if(t.type===`childList`)for(let e of t.addedNodes)e.tagName===`LINK`&&e.rel===`modulepreload`&&n(e)}).observe(document,{childList:!0,subtree:!0});function t(e){let t={};return e.integrity&&(t.integrity=e.integrity),e.referrerPolicy&&(t.referrerPolicy=e.referrerPolicy),t.credentials=e.crossOrigin===`use-credentials`?`include`:e.crossOrigin===`anonymous`?`omit`:`same-origin`,t}function n(e){if(e.ep)return;e.ep=!0;let n=t(e);fetch(e.href,n)}})(),(function(){let e=new Set([`system`,`light`,`dark`]),t=new Set([`sm`,`md`,`lg`,`xl`]);function n(t){let n=String(t||`system`).toLowerCase();return e.has(n)?n:`system`}function r(e){let n=String(e||`md`).toLowerCase();return t.has(n)?n:`md`}function i(e){let t=n(e);return t===`system`?typeof window<`u`&&window.matchMedia&&window.matchMedia(`(prefers-color-scheme: dark)`).matches?`dark`:`light`:t}function a(e,t){let n=t||document.documentElement,r=i(e);return n.dataset.theme=r,n.style.colorScheme=r,r}function o(e,t){let n=t||document.documentElement,i=r(e);return n.dataset.fontScale=i,i}function s(e){if(typeof window>`u`||!window.matchMedia)return function(){};let t=window.matchMedia(`(prefers-color-scheme: dark)`),n=()=>e(t.matches?`dark`:`light`);return typeof t.addEventListener==`function`?(t.addEventListener(`change`,n),function(){t.removeEventListener(`change`,n)}):(t.addListener(n),function(){t.removeListener(n)})}globalThis.SummarizerTheme={THEME_VALUES:e,FONT_SCALE_VALUES:t,normalizeTheme:n,normalizeFontScale:r,resolveTheme:i,applyThemeToDocument:a,applyFontScaleToDocument:o,watchSystemTheme:s,sharedTokens:`
:host, :root {
  --font-display: "Plus Jakarta Sans", "Inter", -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif;
  --font-body: "Inter", -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif;
  --font-mono: "JetBrains Mono", "Fira Code", ui-monospace, SFMono-Regular, Menlo, Monaco, monospace;
  --font-reading: "Newsreader", "Lora", "Georgia", "Charter", "Iowan Old Style", serif;
  --space-1: 4px; --space-2: 8px; --space-3: 12px; --space-4: 16px;
  --space-5: 20px; --space-6: 24px; --space-8: 32px;
  --radius-xs: 5px; --radius-sm: 7px; --radius-md: 10px; --radius-lg: 14px; --radius-full: 9999px;
  
  --color-paper: #FAF8F5;
  --color-paper-2: #F2EFE9;
  --color-paper-elevated: #FFFFFF;
  --color-ink: #1C1917;
  --color-ink-2: #44403C;
  --color-ink-tertiary: #78716C;
  --color-rule: #E7E2DA;
  --color-rule-strong: #D6CEBE;
  
  --color-accent: #9A3412;
  --color-accent-hover: #7C2D12;
  --color-accent-light: #F5EBE1;
  --color-accent-subtle: #FAF4EE;
  --color-focus: #9A3412;
  --color-focus-ring: 0 0 0 3px rgba(154, 52, 18, 0.22);
  
  --color-success: #16A34A;
  --color-error: #DC2626;
  --color-warning: #D97706;

  --bg: var(--color-paper);
  --surface: var(--color-paper-elevated);
  --surface-hover: var(--color-accent-subtle);
  --surface-muted: var(--color-paper-2);
  --text: var(--color-ink);
  --text-secondary: var(--color-ink-2);
  --text-tertiary: var(--color-ink-tertiary);
  --border: var(--color-rule);
  --accent-primary: var(--color-accent);
  --accent-secondary: var(--color-accent-hover);
  --shadow-xs: 0 1px 2px rgba(28, 25, 23, 0.05);
  --shadow-sm: 0 1px 3px rgba(28, 25, 23, 0.07);
  --shadow-md: 0 4px 12px -2px rgba(28, 25, 23, 0.09);
}
:host([data-theme="dark"]), :root[data-theme="dark"] {
  --color-paper: #141210;
  --color-paper-2: #1C1917;
  --color-paper-elevated: #262320;
  --color-ink: #F5F3EF;
  --color-ink-2: #D6D3D1;
  --color-ink-tertiary: #A8A29E;
  --color-rule: #34302C;
  --color-rule-strong: #4E4842;
  
  --color-accent: #E07A5F;
  --color-accent-hover: #F4987E;
  --color-accent-light: #3A231C;
  --color-accent-subtle: #221612;
  --color-focus: #E07A5F;
  --color-focus-ring: 0 0 0 3px rgba(224, 122, 95, 0.35);
  
  --color-success: #22C55E;
  --color-error: #EF4444;
  --color-warning: #F59E0B;

  --bg: var(--color-paper);
  --surface: var(--color-paper-elevated);
  --surface-hover: var(--color-accent-subtle);
  --surface-muted: var(--color-paper-2);
  --text: var(--color-ink);
  --text-secondary: var(--color-ink-2);
  --text-tertiary: var(--color-ink-tertiary);
  --border: var(--color-rule);
  --accent-primary: var(--color-accent);
  --accent-secondary: var(--color-accent-hover);
  --shadow-xs: 0 1px 2px rgba(0, 0, 0, 0.5);
  --shadow-sm: 0 2px 6px rgba(0, 0, 0, 0.5);
  --shadow-md: 0 6px 18px -2px rgba(0, 0, 0, 0.65);
}
`}})(),(function(){globalThis.SummarizerMessages={types:{SUMMARIZE_ACTIVE_TAB:`SUMMARIZE_ACTIVE_TAB`,EXTRACT_CONTENT:`EXTRACT_CONTENT`,FETCH_COURSE_CONTENT:`FETCH_COURSE_CONTENT`,SUMMARY_UPDATED:`SUMMARY_UPDATED`,SUMMARY_CHUNK:`SUMMARY_CHUNK`,SUMMARY_ERROR:`SUMMARY_ERROR`,CANCEL_SUMMARIZE:`CANCEL_SUMMARIZE`,OPEN_SIDE_PANEL:`OPEN_SIDE_PANEL`,GET_PUBLIC_SETTINGS:`GET_PUBLIC_SETTINGS`,DEEP_DIVE_ACTIVE_TAB:`DEEP_DIVE_ACTIVE_TAB`,SETTINGS_UPDATED:`SETTINGS_UPDATED`}}})(),(function(){let e=new Set([`density`]),t={summary:{promptMode:{type:`select`,default:`summarize`,valid:new Set([`summarize`,`analyze`,`explain`,`debate`,`study`,`outline`,`timeline`,`concepts`]),normalize:e=>{let t=String(e||`summarize`).trim()||`summarize`;return t.startsWith(`preset-`)||new Set([`summarize`,`analyze`,`explain`,`debate`,`study`,`outline`,`timeline`,`concepts`]).has(t)?t:`summarize`}},summarySize:{type:`select`,default:`Medium`,valid:new Set([`Brief`,`Medium`,`Deep`])},summaryLength:{type:`select`,default:`Medium`,valid:new Set([`Short`,`Medium`,`Long`])},summaryLanguage:{type:`text`,default:`English`,valid:null,normalize:e=>String(e||`English`).trim()||`English`},summaryTone:{type:`select`,default:`Simple`,valid:new Set([`Simple`,`Concise`,`Friendly`,`Expert`,`Professional`,`Academic`,`Critical`,`Witty`,`Roast`])}},wordTarget:{customFormulaEnabled:{type:`boolean`,default:!1},sizeMultiplierBrief:{type:`number`,default:.05,normalize:e=>Math.max(.01,Math.min(1,Number(e)||.05))},sizeMultiplierMedium:{type:`number`,default:.08,normalize:e=>Math.max(.01,Math.min(1,Number(e)||.08))},sizeMultiplierDeep:{type:`number`,default:.12,normalize:e=>Math.max(.01,Math.min(1,Number(e)||.12))},lengthMultiplierShort:{type:`number`,default:.7,normalize:e=>Math.max(.1,Math.min(5,Number(e)||.7))},lengthMultiplierMedium:{type:`number`,default:1,normalize:e=>Math.max(.1,Math.min(5,Number(e)||1))},lengthMultiplierLong:{type:`number`,default:1.35,normalize:e=>Math.max(.1,Math.min(5,Number(e)||1.35))},charsPerWord:{type:`number`,default:5,normalize:e=>Math.max(1,Math.min(20,Number(e)||5))},minTargetWords:{type:`number`,default:60,normalize:e=>Math.max(10,Math.min(5e3,Math.round(Number(e)||60)))},maxTargetWords:{type:`number`,default:1500,normalize:e=>Math.max(50,Math.min(2e4,Math.round(Number(e)||1500)))},customTargetTemplate:{type:`text`,default:``,normalize:e=>String(e||``).slice(0,1e3)}},display:{theme:{type:`select`,default:`system`,valid:new Set([`system`,`light`,`dark`])},fontScale:{type:`select`,default:`md`,valid:new Set([`sm`,`md`,`lg`,`xl`])}},behavior:{showFloatingUi:{type:`boolean`,default:!1},generateFollowUpQuestions:{type:`boolean`,default:!0},customLanguages:{type:`text`,default:``}},prompts:{customPromptInstructions:{type:`text`,default:``},customSystemInstructions:{type:`text`,default:``},youtubePromptHint:{type:`text`,default:``},webpagePromptHint:{type:`text`,default:``},coursePromptHint:{type:`text`,default:``},selectedTextPromptHint:{type:`text`,default:``},analyzePromptHint:{type:`text`,default:``},explainPromptHint:{type:`text`,default:``},debatePromptHint:{type:`text`,default:``},studyPromptHint:{type:`text`,default:``},outlinePromptHint:{type:`text`,default:``},timelinePromptHint:{type:`text`,default:``},conceptsPromptHint:{type:`text`,default:``},customPromptPresets:{type:`array`,default:[],normalize:e=>Array.isArray(e)?e.map((e,t)=>{if(!e||typeof e!=`object`)return null;let n=String(e.name||``).trim(),r=String(e.systemPrompt||``).trim(),i=String(e.userPrompt||``).trim();return!n||!r&&!i?null:{id:String(e.id||`preset-`+Date.now().toString(36)+`-`+t),name:n.slice(0,80),systemPrompt:r.slice(0,4e3),userPrompt:i.slice(0,8e3),createdAt:e.createdAt||new Date().toISOString(),updatedAt:e.updatedAt||new Date().toISOString()}}).filter(Boolean).slice(0,50):[]}},advancedPrompts:{promptAdvancedMode:{type:`object`,default:{youtube:!1,webpage:!1,course:!1,selectedText:!1,chapter:!1}},customSystemPrompt:{type:`object`,default:{youtube:``,webpage:``,course:``,selectedText:``,chapter:``}},customUserPrompt:{type:`object`,default:{youtube:``,webpage:``,course:``,selectedText:``,chapter:``}}},providers:{provider:{type:`select`,default:`gemini`,valid:new Set([`gemini`,`openai`,`local`])},gemini:{type:`object`,default:{apiKey:``,model:`gemini-3.5-flash-lite`,useGeminiDirectVideo:!1}},openai:{type:`object`,default:{apiKey:``,model:`gpt-4o-mini`,baseUrl:`https://api.openai.com/v1`}},local:{type:`object`,default:{baseUrl:`http://127.0.0.1:11434`,model:`llama3.1`,endpointType:`ollama`}}}};function n(){let e={};return Object.values(t).forEach(t=>{Object.keys(t).forEach(n=>{e[n]=t[n].default})}),e}let r=n();function i(e){for(let n of Object.values(t))if(e in n&&n[e].valid)return n[e].valid;return null}function a(n){if(!n||typeof n!=`object`)return{};let r={};return Object.values(t).forEach(e=>{Object.keys(e).forEach(t=>{let i=e[t],a=n[t];a!=null&&(i.normalize?r[t]=i.normalize(a):i.valid&&i.valid instanceof Set?r[t]=i.valid.has(a)?a:i.default:i.type===`boolean`?r[t]=!!a:i.type===`object`?a&&typeof a==`object`&&!Array.isArray(a)?r[t]=Object.assign({},i.default,a):r[t]=i.default:r[t]=a)})}),Object.keys(n).forEach(t=>{!(t in r)&&!e.has(t)&&(r[t]=n[t])}),r}function o(e,t){let n=Array.isArray(e)?e.slice():{...e};return Object.keys(t||{}).forEach(r=>{let i=t[r];i&&typeof i==`object`&&!Array.isArray(i)?n[r]=o(e[r],i):n[r]=i}),n}globalThis.SummarizerSettingsSchema={SECTIONS:t,DEFAULTS:r,normalizeSettings:a,deepMerge:o,getValidValues:i,buildDefaults:n}})(),(function(){let e=!1;function t(){return globalThis.browser&&globalThis.browser.runtime?globalThis.browser:globalThis.chrome}function n(){let e=t();return!!(e&&e.sidePanel&&typeof e.sidePanel.open==`function`)}function r(){let e=t();return!!(e&&e.sidebarAction&&typeof e.sidebarAction.open==`function`)}function i(){return n()||r()}async function a(){let i=t();if(n()&&typeof i.sidePanel.setPanelBehavior==`function`)try{await i.sidePanel.setPanelBehavior({openPanelOnActionClick:!0})}catch{}!e&&r()&&i.action&&i.action.onClicked&&(i.action.onClicked.addListener(async()=>{try{await i.sidebarAction.open()}catch{}}),e=!0)}async function o(e,r){let i=t();n()&&typeof i.sidePanel.setOptions==`function`&&e&&await i.sidePanel.setOptions(r?{tabId:e,path:`sidepanel.html`,enabled:!0}:{tabId:e,enabled:!1})}function s(e){let i=t(),a=e||{};if(n()){let e=i.sidePanel.open(a),t=a.tabId?o(a.tabId,!0):Promise.resolve();return Promise.all([e,t]).then(([e])=>e)}if(r())return i.sidebarAction.open();throw Error(`Sidebar API is unavailable.`)}globalThis.SummarizerBrowserApi={getApi:t,hasChromeSidePanel:n,hasFirefoxSidebar:r,hasSupportedSidebar:i,configurePrimarySidebarBehavior:a,openPrimarySidebar:s,setSidePanelEnabledForTab:o}})(),(function(){let e=`summarizerSettings`,t=[`summarizerResultsByTab`,`summarizerConversationsByTab`,`summarizerWorkflowByTab`],n=SummarizerSettingsSchema.DEFAULTS,r=null,i=null,a=Promise.resolve();function o(e){return new Promise((t,n)=>{chrome.storage.local.get(e,e=>{if(chrome.runtime.lastError){n(Error(`Storage read failed: `+chrome.runtime.lastError.message));return}t(e)})})}function s(e){return new Promise((t,n)=>{chrome.storage.local.set(e,()=>{if(chrome.runtime.lastError){n(Error(`Storage write failed: `+chrome.runtime.lastError.message));return}t()})})}function c(e){return new Promise((t,n)=>{chrome.storage.local.remove(e,()=>{if(chrome.runtime.lastError){n(Error(`Storage cleanup failed: `+chrome.runtime.lastError.message));return}t()})})}function l(e){if(globalThis.SummarizerSettingsSchema&&typeof SummarizerSettingsSchema.normalizeSettings==`function`){let t=SummarizerSettingsSchema.normalizeSettings(e||{});return[`gemini`,`openai`,`local`].forEach(e=>{t[e]&&(typeof t[e].apiKey==`string`&&(t[e].apiKey=t[e].apiKey.trim()),typeof t[e].baseUrl==`string`&&(t[e].baseUrl=t[e].baseUrl.trim().replace(/\/$/,``)))}),t}return!e||typeof e!=`object`?{}:{...e}}function u(e){if(Array.isArray(e))return e.map(e=>u(e));if(!e||typeof e!=`object`)return e;let t={};return Object.keys(e).forEach(n=>{t[n]=u(e[n])}),t}async function d(){return r||(i||=o([e]).then(t=>{let i=l(t[e]||{});return r=SummarizerSettingsSchema.deepMerge(n,i),r}).finally(()=>{i=null}),await i),u(r)}function f(t){let n=a.then(async()=>{let n=await d(),i=SummarizerSettingsSchema.deepMerge(n,t||{});return await s({[e]:i}),r=i,u(i)});return a=n.catch(()=>{}),n}async function p(){await c(t)}chrome.storage&&chrome.storage.onChanged&&chrome.storage.onChanged.addListener((t,i)=>{if(i!==`local`||!t[e])return;let a=l(t[e].newValue||{});r=SummarizerSettingsSchema.deepMerge(n,a)}),globalThis.SummarizerStorage={getSettings:d,saveSettings:f,clearLegacySessionData:p}})();